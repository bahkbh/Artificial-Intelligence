#pragma once
#define SQUARE(x) ((x)*(x))
#define CUBE(x) ((x)*(x)*(x))