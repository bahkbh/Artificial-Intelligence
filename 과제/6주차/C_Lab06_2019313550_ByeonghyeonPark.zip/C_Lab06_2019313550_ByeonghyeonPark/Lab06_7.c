#include <stdio.h>

#define gfgn 5

#ifdef gfg
#undef gfg
#define gfg 200
#else
#define gfg 50
#endif

int main(){
    printf("gfg: %d", gfg);
    return 0;
}