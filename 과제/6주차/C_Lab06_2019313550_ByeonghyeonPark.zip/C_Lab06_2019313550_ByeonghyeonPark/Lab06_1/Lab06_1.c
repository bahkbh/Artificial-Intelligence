#include <stdio.h>
#include "myheader.h"

int main() {
	add(4, 6);
	/* This calls add function written in myheader.h
	and therefore no compliation error. */

	multiply(5, 5);

	printf("Bye! See you Soon");
	return 0;
}