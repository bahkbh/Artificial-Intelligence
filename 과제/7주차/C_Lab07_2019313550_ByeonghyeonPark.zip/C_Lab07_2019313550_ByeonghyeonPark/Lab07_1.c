#include <stdio.h>

int main() {
	int arrTest00[5] = {8, 9, 10, 8, 7};
	int arrTest01[] = {8, 9, 10, 8, 7};
	int arrTest02[5] = {8};

	printf("%d %d %d %d %d\n", arrTest00[0], arrTest00[1], arrTest00[2], arrTest00[3], arrTest00[4]);
	printf("%d %d %d %d %d\n", arrTest01[0], arrTest01[1], arrTest01[2], arrTest01[3], arrTest01[4]);
	printf("%d %d %d %d %d\n", arrTest02[0], arrTest02[1], arrTest02[2], arrTest02[3], arrTest02[4]);
	return 0;
}