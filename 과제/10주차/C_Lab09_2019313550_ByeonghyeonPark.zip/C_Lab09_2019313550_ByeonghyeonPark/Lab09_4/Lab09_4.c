#include "ex_header.h"
#include <stdio.h>

int main(void) {
	printf("%d", extern_test);
}