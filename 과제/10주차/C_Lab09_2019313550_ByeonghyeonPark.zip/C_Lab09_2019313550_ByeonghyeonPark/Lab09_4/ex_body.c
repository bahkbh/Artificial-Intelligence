#include "ex_header.h"

int extern_test = 10032023;