#include<stdio.h>
#include<string.h>

int main(){
    char str1[14];
    strcpy_s(str1, 14, "hello ");
    printf("%s\n", str1);

    char str2[7];
    strcpy_s(str2, 7, "world!");
    printf("%s\n",str2);

    strcat_s(str1, 14, str2);
    printf("%s\n",str1);

    return 0;
}