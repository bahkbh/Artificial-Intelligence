#include<stdio.h>
#include<string.h>

int main(){
    char str1[20] = "C programming";
    char str2[20];

    // comping str1 to str2
    strcpy_s(str2, 20, str1);
    //strcpy(sstr2, str1);
    puts(str2);// C programming

    return 0;
}