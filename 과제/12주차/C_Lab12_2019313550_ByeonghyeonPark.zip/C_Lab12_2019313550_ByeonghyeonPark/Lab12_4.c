#include <stdio.h>

int main(){
	//char greeting[]= "Hello";
    char* greeting= "Hello";
	printf("Greeting message: %s\n",greeting);
	return 0;
}