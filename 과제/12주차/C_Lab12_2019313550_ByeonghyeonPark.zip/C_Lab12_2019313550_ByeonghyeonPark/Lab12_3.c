#include <stdio.h>

int main(){
	char greeting[]= {'H', 'e', 'l','l','o','\0'};
	//char greeting[]= "Hello";
	printf("Greeting message: %s\n",greeting);
	return 0;
}