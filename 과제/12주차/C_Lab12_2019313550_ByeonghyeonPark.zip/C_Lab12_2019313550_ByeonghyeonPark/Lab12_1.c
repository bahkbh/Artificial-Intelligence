#include <stdio.h>
#include <stdlib.h>

int main(){
	int* x; // allocate the pointers x

	x = malloc(sizeof(int)); //Aloocate an int pointee, and set x to point ot it
	
	*x = 42; //Derefeence x to store 42 in its pointee

	printf("Value at *x = %d \n", *x);

	free(x);
	return 0; 
}