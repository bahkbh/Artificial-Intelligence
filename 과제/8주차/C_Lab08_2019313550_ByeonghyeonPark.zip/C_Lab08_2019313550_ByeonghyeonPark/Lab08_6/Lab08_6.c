#include <stdio.h>
#include "mymath.h"

int main() {
	printf("%d\n", power(2, 9));
	printf("%d\n", fact(5));

	return 0;
}