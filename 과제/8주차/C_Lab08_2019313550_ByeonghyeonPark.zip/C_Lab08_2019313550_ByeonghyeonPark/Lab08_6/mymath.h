#pragma once
int fact(int n);
int power(int base, int exp);