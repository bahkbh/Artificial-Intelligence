#include <stdio.h>

int main(){
    int a = 500;
    int b = 300;

    if (a == 100) {
        if (b == 200){
            printf("Value of a is 100 and b is 200\n");
        }
    }

    printf("Exact vale of a is : %d\n", a);
    printf("Exact value of b is : %d\n", b);

    return 0;
}