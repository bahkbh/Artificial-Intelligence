#include <stdio.h>

int main(){
    int dice1, dice2, cnt = 0;

    printf("=================\n");
    printf("�ֻ���1 �ֻ���2\n");
    printf("=================\n");
    for (dice1 = 1; dice1 < 7; dice1++){
        for (dice2 = 1; dice2 < 7; dice2++){
            if (7-dice1==dice2){
            printf("%7d %7d\n", dice1, dice2);
            cnt++;
            }
        }
    }
    printf("=================\n");
    printf("      �� %d����\n",cnt);
    return 0;
}