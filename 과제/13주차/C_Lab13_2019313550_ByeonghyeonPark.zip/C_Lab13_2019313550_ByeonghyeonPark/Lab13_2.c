#include <stdio.h>
#include <string.h>

// create struct with person1 variable

typedef struct Pserson{
	char name[50];
	int citNo;
	float salary;
} person;

int main(){
	// create Person variable
	person p1;

	// assign value to name of p1
	strcpy_s(p1.name, 50, "George Orwell");

	// assign values to other person1 variables
	p1.citNo = 1984;
	p1.salary = 2500;

	// print struct variables
	printf("Name: %s\n",p1.name);
	printf("Citizenship No.: %d\n",p1.citNo);
	printf("Salary: %.2f", p1.salary);
	
	return 0;
}