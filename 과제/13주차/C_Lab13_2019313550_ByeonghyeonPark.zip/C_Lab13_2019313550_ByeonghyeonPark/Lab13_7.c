#include <stdio.h>
struct student{
    char name[50];
    int age;
};

// function prototype
struct student getinformation();

int main(){
    struct student s;
    s = getinformation();
    printf("\nDisplaying information\n");
    printf("Name: %s", s.name);
    printf("\nRoll: %d", s.age);
    return 0;
}

struct student getinformation(){
    struct student s1;

    printf("Enter name: ");
    scanf("%s",s1.name, sizeof(s1.name));
    printf("Enter age: ");
    scanf("%d",&s1.age);
    return s1;
}