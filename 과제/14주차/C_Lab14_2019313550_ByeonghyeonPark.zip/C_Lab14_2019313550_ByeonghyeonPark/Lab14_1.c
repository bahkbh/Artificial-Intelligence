#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

int main(){
    FILE* fp;
    errno_t err;

    err = fopen_s(&fp,"text.txt","r+");
    if (err != 0){
        printf("Please check the file to read!\n");
        exit(0);
    } else{
        printf("file reading test using fopen() in C\n");
        fclose(fp);
    }

    return 0;
}