#include <stdio.h>

int main(){
    char str[100];

    printf("Enter a value : ");
    fgets(str, 15, stdin);

    printf("You entered : %s", str);
    return 0;
}