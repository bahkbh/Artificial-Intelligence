#include <stdio.h>

int main(){
    int a;
    float b =3.14;

    printf("Enter a number(int) : ");
    scanf("%d",&a);
    printf("Enter a number(float) : ");
    scanf("%f",&b);

    printf("The int variable : %d\n", a);
    printf("The float variable : %f\n", b);
    return 0;
}