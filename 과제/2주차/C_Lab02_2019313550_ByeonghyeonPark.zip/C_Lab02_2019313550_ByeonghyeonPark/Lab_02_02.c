#include <stdio.h>

int main(){
    int a = 1;
    char b = 'G';
    double c = 3.14;

    printf("Hello World\n");

    printf("Hello I am a character. My value is %c and my size is %lu bytes. \n", b, sizeof(char));

    printf("Hello I am a integer. My value is %d and my size is %lu bytes. \n", a, sizeof(int));

    printf("Hello I am a double. My value is %g of %lf and my size is %lu bytes. \n", c, c, sizeof(double));

    printf("Hello I am a double. My value is %.2g of %.2lf and my size is %lu bytes. \n", c, c, sizeof(double));
    
    printf("Bye! See you soon. \n");
    return 0;
}